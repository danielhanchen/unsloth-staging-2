"""pr_ui_diff stops both Studios however the shoot ends, and leaves signal handling as it found it.

`main()` runs with the install, login and scene stubbed, but the launch is the real
`launch_studio` against a fake `unsloth` CLI, so a leak is a real process left in a real
session. One case per row:
  clean run                              -> both sessions gone, handlers restored
  scene raises on AFTER                  -> both gone, the error propagates
  launch raises after spawning           -> that side's session is still stopped
  SIGTERM mid-scene                      -> SystemExit(143), both gone
  SIGTERM again during the stops         -> the stops still finish
  SIGHUP already ignored (nohup)         -> stays ignored, the run completes
"""

from __future__ import annotations

import os
import shutil
import signal
import sys
import tempfile
import types
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPTS))

import pr_ui_diff  # noqa: E402
from studio_test_kit import lifecycle  # noqa: E402
from studio_test_kit.lifecycle import StudioInstall  # noqa: E402

BASE, HEAD = "a" * 40, "b" * 40
REAL_LAUNCH, REAL_STOP = lifecycle.launch_studio, lifecycle.stop_studio

scene = types.ModuleType("pr_ui_scenes.fake_stops")
sys.modules["pr_ui_scenes.fake_stops"] = scene


def _run(tmp: Path, drive, launch=None, stop=None, launched=None) -> list[StudioInstall]:
    launched = [] if launched is None else launched

    async def _drive(session, out_dir, label, **kw):
        drive(label)
        return [], {"label": label}

    scene.drive = _drive

    def _install(side, log_dir):
        side.home.mkdir(parents=True, exist_ok=True)
        (side.home / "bin").mkdir(exist_ok=True)
        cli = side.home / "bin" / "unsloth"
        # A child in its own process group, as Studio starts llama-server.
        cli.write_text("#!/bin/bash\n"
                       "python3 -c 'import os, time; os.setpgid(0, 0); time.sleep(600)' &\n"
                       "exec sleep 600\n")
        cli.chmod(0o755)
        return StudioInstall(home=side.home, repo=side.worktree, branch=side.sha)

    def _launch(inst, port, log, extra_env=None, **kw):
        launched.append(inst)
        return (launch or REAL_LAUNCH)(inst, port, log, extra_env=extra_env,
                                       **{**kw, "wait_for_healthz": False})

    pr_ui_diff.resolve_shas = lambda repo, pr, gh_repo: (BASE, HEAD, "branch")
    pr_ui_diff.make_worktree = lambda repo, sha, dest: dest
    pr_ui_diff.install_side = _install
    pr_ui_diff.launch_studio = _launch
    pr_ui_diff.stop_studio = stop or (lambda inst: REAL_STOP(inst, timeout_s=5))
    pr_ui_diff.studio_session = lambda url, home, pw: object()
    pr_ui_diff.password_for = lambda root, home, override: "pw"
    pr_ui_diff._reset_threads = lambda session: 0
    sys.argv = ["pr_ui_diff.py", "--pr", "8222", "--scene", "fake_stops", "--root", str(tmp),
                "--allow-identical"]
    try:
        pr_ui_diff.main()
    finally:
        # Whatever main() did, nothing it launched may still be running.
        for inst in launched:
            left = lifecycle._session_members(inst.pid) if inst.pid else []
            if left:
                REAL_STOP(inst, timeout_s=2)
            assert not left, f"{inst.home.name}: session {inst.pid} left running: {left}"
    return launched


def _case(fn):
    tmp = Path(tempfile.mkdtemp(prefix="uidiff_stops_"))
    marker = lambda s, f: None  # noqa: E731
    saved = {n: signal.signal(n, marker) for n in (signal.SIGTERM, signal.SIGHUP)}
    try:
        fn(tmp)
        for n in saved:
            assert signal.getsignal(n) is marker, f"{signal.Signals(n).name} handler not restored"
    finally:
        for n, h in saved.items():
            signal.signal(n, h)
        shutil.rmtree(tmp, ignore_errors=True)


def test_clean_run_stops_both() -> None:
    _case(lambda tmp: _assert_len(_run(tmp, lambda label: None), 2))


def test_scene_error_stops_both() -> None:
    def body(tmp):
        def drive(label):
            if label == "AFTER":
                raise RuntimeError("scene broke")
        launched: list[StudioInstall] = []
        try:
            _run(tmp, drive, launched=launched)
        except RuntimeError as e:
            assert "scene broke" in str(e)
        else:
            raise AssertionError("the scene error was swallowed")
        assert len(launched) == 2, launched
    _case(body)


def test_launch_error_after_spawn_stops_that_side() -> None:
    def launch(inst, port, log, **kw):
        REAL_LAUNCH(inst, port, log, **kw)
        raise TimeoutError("no /api/health")

    def body(tmp):
        launched: list[StudioInstall] = []
        try:
            _run(tmp, lambda label: None, launch=launch, launched=launched)
        except TimeoutError:
            pass
        else:
            raise AssertionError("the launch error was swallowed")
        assert len(launched) == 1 and launched[0].pid, launched
    _case(body)


def test_sigterm_mid_scene_stops_both() -> None:
    def drive(label):
        if label == "AFTER":
            os.kill(os.getpid(), signal.SIGTERM)

    def body(tmp):
        launched: list[StudioInstall] = []
        try:
            _run(tmp, drive, launched=launched)
        except SystemExit as e:
            assert e.code == 128 + signal.SIGTERM, e.code
        else:
            raise AssertionError("SIGTERM did not end the run")
        assert len(launched) == 2, launched
    _case(body)


def test_second_sigterm_does_not_cut_the_stops_short() -> None:
    def stop(inst):
        os.kill(os.getpid(), signal.SIGTERM)  # arrives while the first side is stopping
        return REAL_STOP(inst, timeout_s=5)

    def drive(label):
        if label == "AFTER":
            os.kill(os.getpid(), signal.SIGTERM)

    def body(tmp):
        launched: list[StudioInstall] = []
        try:
            _run(tmp, drive, stop=stop, launched=launched)
        except SystemExit as e:
            assert e.code == 128 + signal.SIGTERM, e.code
        else:
            raise AssertionError("SIGTERM did not end the run")
        assert len(launched) == 2, launched
    _case(body)


def test_ignored_sighup_stays_ignored() -> None:
    tmp = Path(tempfile.mkdtemp(prefix="uidiff_stops_"))
    saved = signal.signal(signal.SIGHUP, signal.SIG_IGN)
    try:
        _assert_len(_run(tmp, lambda label: os.kill(os.getpid(), signal.SIGHUP)), 2)
        assert signal.getsignal(signal.SIGHUP) == signal.SIG_IGN, "nohup's SIG_IGN was replaced"
    finally:
        signal.signal(signal.SIGHUP, saved)
        shutil.rmtree(tmp, ignore_errors=True)


def _assert_len(xs, n):
    assert len(xs) == n, xs


TESTS = [
    test_clean_run_stops_both,
    test_scene_error_stops_both,
    test_launch_error_after_spawn_stops_that_side,
    test_sigterm_mid_scene_stops_both,
    test_second_sigterm_does_not_cut_the_stops_short,
    test_ignored_sighup_stays_ignored,
]


def main() -> int:
    failed = 0
    for t in TESTS:
        try:
            t()
            print(f"ok    {t.__name__}")
        except BaseException as e:  # noqa: BLE001 - SystemExit is a failure here too
            failed += 1
            print(f"FAIL  {t.__name__}: {type(e).__name__}: {e}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
