"""pr_ui_prebuild.py must resolve a relative --root the way pr_ui_diff.py does.

install.sh runs with cwd inside the worktree and is handed only UNSLOTH_STUDIO_HOME, so
a RELATIVE --root built both Studios under <worktree>/<root>/home_*. The prebuild said
"built", wrote its stamps beside the caller's empty <root>/home_*, and the later
`pr_ui_diff.py --skip-install` found no CLI there. Observed on PR 13482.

Run: python3 pr_ui_scenes/test_pr_ui_prebuild_root.py
"""

from __future__ import annotations

import contextlib
import io
import os
import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPTS))

import pr_ui_prebuild  # noqa: E402

try:
    import pytest
except ImportError:  # run as a script
    pytest = None

if pytest is not None:
    @pytest.fixture
    def tmp(tmp_path: Path) -> Path:
        return tmp_path


def _check(name: str, got, want) -> None:
    if got != want:
        raise AssertionError(f"{name}: got {got!r}, want {want!r}")
    print(f"ok    {name}")


def run(root_arg: str) -> list[Path]:
    """``main()`` with the SHA lookup, worktree and install stubbed; returns the homes."""
    homes: list[Path] = []
    pr_ui_prebuild.resolve_shas = lambda repo, pr, gh_repo: ("a" * 40, "b" * 40, "some-branch")
    pr_ui_prebuild.make_worktree = lambda repo, sha, dest: dest

    def _install(side, log_dir):
        homes.append(side.home)
        side.home.mkdir(parents=True, exist_ok=True)

    pr_ui_prebuild.install_side = _install
    sys.argv = ["pr_ui_prebuild.py", "--pr", "13482", "--root", root_arg]
    with contextlib.redirect_stdout(io.StringIO()):
        pr_ui_prebuild.main()
    return homes


def test_a_relative_root_is_resolved(tmp: Path) -> None:
    cwd = os.getcwd()
    try:
        os.chdir(tmp)
        homes = run("outputs/rel_root")
    finally:
        os.chdir(cwd)
    _check("both homes are absolute", [h.is_absolute() for h in homes], [True, True])
    _check("and under the cwd the caller meant",
           [str(h).startswith(str(Path(tmp).resolve())) for h in homes], [True, True])
    # The stamp is what --skip-install keys on: it has to sit beside the built home.
    _check("each stamp sits in its home", [(h / ".uidiff_sha").is_file() for h in homes], [True, True])


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="uidiff_prebuild_") as td:
        try:
            test_a_relative_root_is_resolved(Path(td))
        except AssertionError as exc:
            print(f"FAIL  {exc}")
            return 1
    print("\nall prebuild root checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
