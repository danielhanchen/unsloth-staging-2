"""Long-chat scroll / open / type bench for #16854 (WebKitGTK windowing) and #16782 (paint bounds).

Live Studio (frontend chosen at launch by the driver), seeded thread, fresh context per engine.
Per engine (chromium, webkit; Playwright's Linux WebKit is detected as WebKitGTK by the app):
  open      ms from navigation to the composer and to the full history mounted
  scroll    rAF frame gaps while wheel-scrolling the middle of the thread (p50 / p95 / max,
            frames over 50 ms), and blank samples: visible messages with no rendered text
  jump      scrollbar-style jumps (scrollTop set to 10/50/90/30%): blank visible messages one
            and three frames after each jump, and the frame gap of the jump
  type      keydown -> second animation frame per key in the composer
  windowed  messages carrying data-message-windowed (engagement of #16854's windowing)

  python scroll_bench.py --base-url URL --home HOME --thread TID --arm A --rep R --out x.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import statistics
import sys
from pathlib import Path

sys.path.insert(0, os.environ.get("PACK", str(Path(__file__).resolve().parent)))

from pr_ui_scenes._common import studio_session  # noqa: E402
from studio_test_kit.auth import seed_init_script  # noqa: E402

from playwright.async_api import async_playwright  # noqa: E402

PASSWORD = "r16656-bench-pass-1"

HELPERS = """
() => {
  const vp = () => document.querySelector('.aui-thread-viewport');
  window.__blank = () => {
    const v = vp(); if (!v) return {visible: 0, blank: 0};
    const r = v.getBoundingClientRect();
    let visible = 0, blank = 0;
    for (const m of v.querySelectorAll('[data-role][data-message-id]')) {
      const b = m.getBoundingClientRect();
      if (b.bottom < r.top + 4 || b.top > r.bottom - 4 || b.height < 8) continue;
      visible++;
      if (!(m.innerText || '').trim()) blank++;
    }
    return {visible, blank};
  };
  window.__frames = (ms) => new Promise((done) => {
    const gaps = []; const samples = []; let last = performance.now(); const end = last + ms;
    const tick = (t) => {
      gaps.push(t - last); last = t; samples.push(window.__blank().blank);
      if (t < end) requestAnimationFrame(tick); else done({gaps, samples});
    };
    requestAnimationFrame((t) => { last = t; requestAnimationFrame(tick); });
  });
  window.__nf = (n) => new Promise((done) => { const step = (k) => k ? requestAnimationFrame(() => step(k - 1)) : done(); step(n); });
  return true;
}
"""


def pct(xs, q):
    if not xs:
        return None
    s = sorted(xs)
    return round(s[min(len(s) - 1, int(q * len(s)))], 1)


async def run_engine(p, engine, base, tid, init, expected):
    browser = await getattr(p, engine).launch()
    ctx = await browser.new_context(viewport={"width": 1440, "height": 900})
    await ctx.add_init_script(init)
    page = await ctx.new_page()
    out = {"engine": engine}
    try:
        t0 = asyncio.get_event_loop().time()
        await page.goto(f"{base}/chat?thread={tid}", wait_until="domcontentloaded")
        await page.wait_for_selector("form textarea", timeout=120_000)
        out["open_composer_ms"] = round((asyncio.get_event_loop().time() - t0) * 1000)
        mounted_at = None
        last_n, stable_since = -1, None
        for _ in range(600):
            n = await page.evaluate("() => document.querySelectorAll('[data-role][data-message-id]').length")
            now = asyncio.get_event_loop().time()
            if n >= expected:
                mounted_at = now
                break
            if n != last_n:
                last_n, stable_since = n, now
            elif stable_since and now - stable_since > 8:
                break
            await page.wait_for_timeout(200)
        out["mounted_messages"] = last_n if mounted_at is None else expected
        out["open_all_ms"] = round(((mounted_at or asyncio.get_event_loop().time()) - t0) * 1000)
        await page.wait_for_timeout(3000)
        await page.evaluate(HELPERS)
        out["windowed"] = await page.evaluate("() => document.querySelectorAll('[data-message-windowed]').length")
        # scroll from the middle, wheel steps, frames recorded in-page
        await page.evaluate("() => { const v = document.querySelector('.aui-thread-viewport'); v.scrollTop = v.scrollHeight / 2; }")
        await page.wait_for_timeout(1500)
        await page.mouse.move(720, 420)
        rec = asyncio.ensure_future(page.evaluate("(ms) => window.__frames(ms)", 6000))
        for i in range(48):
            await page.mouse.wheel(0, -300 if i < 24 else 300)
            await page.wait_for_timeout(50)
        fr = await rec
        gaps = fr["gaps"][1:]
        out["scroll"] = {"frames": len(gaps), "p50": pct(gaps, 0.5), "p95": pct(gaps, 0.95),
                         "max": round(max(gaps), 1) if gaps else None,
                         "over50": sum(1 for g in gaps if g > 50),
                         "blank_frames": sum(1 for b in fr["samples"] if b > 0)}
        # scrollbar-style jumps
        jumps = []
        for frac in (0.1, 0.5, 0.9, 0.3):
            j = await page.evaluate("""async (f) => {
              const v = document.querySelector('.aui-thread-viewport');
              const t = performance.now();
              v.scrollTop = (v.scrollHeight - v.clientHeight) * f;
              await new Promise((r) => requestAnimationFrame(r));
              const gap = performance.now() - t;
              const b1 = window.__blank().blank;
              await window.__nf(3);
              const b3 = window.__blank();
              return {gap, b1, b3: b3.blank, visible: b3.visible};
            }""", frac)
            jumps.append(j)
            await page.wait_for_timeout(800)
        out["jump"] = {"gap_max": round(max(j["gap"] for j in jumps), 1),
                       "blank_after_1": sum(j["b1"] for j in jumps),
                       "blank_after_3": sum(j["b3"] for j in jumps),
                       "visible": sum(j["visible"] for j in jumps)}
        # typing
        await page.evaluate("""() => {
          window.__lat = [];
          document.addEventListener('keydown', (e) => {
            const t0 = e.timeStamp;
            requestAnimationFrame(() => requestAnimationFrame(() => window.__lat.push(performance.now() - t0)));
          }, {capture: true});
        }""")
        box = page.locator("form textarea").first
        await box.click()
        await page.wait_for_timeout(800)
        await page.evaluate("() => { window.__lat = []; }")
        for ch in "long chat typing probe":
            await page.keyboard.press("Space" if ch == " " else ch)
            await page.wait_for_timeout(120)
        await page.wait_for_timeout(400)
        lat = await page.evaluate("() => window.__lat.slice()")
        out["type"] = {"p50": pct(lat, 0.5), "p95": pct(lat, 0.95), "n": len(lat)}
    except Exception as exc:  # noqa: BLE001
        out["error"] = repr(exc)[:400]
    finally:
        await ctx.close()
        await browser.close()
    return out


async def main_async(a):
    s = studio_session(a.base_url, Path(a.home), PASSWORD)
    auth = type("A", (), {"access_token": s.access_token, "refresh_token": s.refresh_token})()
    init = seed_init_script(auth, [])
    res = {"arm": a.arm, "rep": a.rep, "engines": {}}
    async with async_playwright() as p:
        for engine in a.engines.split(","):
            r = await run_engine(p, engine, a.base_url, a.thread, init, a.expected)
            res["engines"][engine] = r
            print("SCROLL", json.dumps({"arm": a.arm, "rep": a.rep, **r}), flush=True)
    Path(a.out).write_text(json.dumps(res))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--thread", required=True)
    ap.add_argument("--arm", required=True)
    ap.add_argument("--rep", type=int, default=0)
    ap.add_argument("--expected", type=int, default=600)
    ap.add_argument("--engines", default="webkit,chromium")
    ap.add_argument("--out", required=True)
    return asyncio.run(main_async(ap.parse_args()))


if __name__ == "__main__":
    raise SystemExit(main())
