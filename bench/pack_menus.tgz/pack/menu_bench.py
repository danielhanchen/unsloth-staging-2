"""Open/close cost of every chat-page surface (settings, browser pane, menus, pickers, sidebar) on a
short thread vs a long one, where the long thread is the short one repeated: N x P.

P = one fixed turn: a question, then an assistant reply with reasoning, a web_search call with six
URL sources, a python tool call, and an answer with prose, a code fence, a table, a list and math.
Every turn is identical except its index, so N=100 is exactly 100 copies of N=1. Deterministic: no
RNG, fixed viewport, fixed surface order.

  seed   python menu_bench.py seed --base-url URL --home HOME --turns 1 100 --out threads.json
  run    python menu_bench.py run --base-url URL --home HOME --threads threads.json --arm main
                                  --engines chromium,webkit --out menus_main.json [--shots DIR]

Per surface and engine: CYCLES untraced open/close cycles (wall: input event -> first painted frame
with the surface visible, -> last DOM mutation, longest frame gap), then on Chromium one traced cycle
giving engine-independent work counts: elements restyled, layout objects, and style / layout / paint /
main-thread-busy milliseconds. A surface whose trigger does not produce it is reported NOT_RUN.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import statistics
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, os.environ.get("PACK", str(Path(__file__).resolve().parent)))

from pr_ui_scenes._common import api_post, studio_session  # noqa: E402
from studio_test_kit.auth import seed_init_script  # noqa: E402

PASSWORD = "r16656-bench-pass-1"
CYCLES = int(os.environ.get("MENU_CYCLES", "3"))

PARA = ("The scheduler drains each buffer before the next commit, so the observer sees a stable layout "
        "and the shard boundary stays aligned with the token lane. Gradient checkpoints are written per "
        "epoch, the adapter keeps its rotary cache warm, and the sampler reuses the prompt template.")
CODE = "\n".join(f"def step_{k}(x):\n    return sum(v * {k} for v in range(x))\n" for k in range(6))
TABLE = "| step | loss | lr |\n|---|---|---|\n" + "\n".join(f"| {k} | 0.{k}4 | 2e-4 |" for k in range(5))


def turn(tid: str, t: int, parent: str | None, t0: int) -> list[dict]:
    uid, aid = f"{tid}-u{t}", f"{tid}-a{t}"
    q = {"query": f"scheduler buffer reference {t}"}
    c = {"code": f"print(sum(range({t + 10})))"}
    parts = [
        {"type": "reasoning", "text": f"Turn {t}. " + " ".join([PARA] * 8)},
        {"type": "tool-call", "toolCallId": f"ws_{t}", "toolName": "web_search", "argsText": json.dumps(q),
         "args": q, "state": "result", "result": " ".join([PARA] * 4)},
        *[{"type": "source", "sourceType": "url", "id": f"src_{t}_{s}", "url": f"https://example{s}.org/t{t}",
           "title": f"Source {s} for turn {t}"} for s in range(6)],
        {"type": "tool-call", "toolCallId": f"py_{t}", "toolName": "python", "argsText": json.dumps(c),
         "args": c, "state": "result", "result": " ".join([PARA] * 2)},
        {"type": "text", "text": "\n\n".join([
            f"Answer {t}. {PARA}", f"```python\n# turn {t}\n{CODE}```", TABLE,
            f"The update is $\\theta_{{t+1}} = \\theta_t - \\eta \\nabla L_{{{t}}}$.",
            "$$\n\\mathcal{L} = -\\sum_{i=1}^{N} y_i \\log \\hat{y}_i\n$$",
            "- " + "\n- ".join([PARA[:120]] * 4), PARA])},
    ]
    return [
        {"id": uid, "threadId": tid, "parentId": parent, "role": "user",
         "content": [{"type": "text", "text": f"Question {t}: {PARA} Use `trainer.step()` here?"}],
         "createdAt": t0 + 2 * t},
        {"id": aid, "threadId": tid, "parentId": uid, "role": "assistant", "content": parts,
         "createdAt": t0 + 2 * t + 1},
    ]


def _put(session, path: str, payload: dict) -> dict:
    req = urllib.request.Request(session.base_url + path, data=json.dumps(payload).encode(), method="PUT",
                                 headers={"Content-Type": "application/json",
                                          "Authorization": f"Bearer {session.access_token}"})
    with urllib.request.urlopen(req, timeout=600) as resp:
        return json.loads(resp.read() or b"{}")


def cmd_seed(a) -> int:
    s = studio_session(a.base_url, Path(a.home), PASSWORD)
    t0 = 1_767_225_600_000
    out = {}
    for n in a.turns:
        tid = f"menus-{n}x"
        api_post(s, "/api/chat/threads", {"id": tid, "title": f"Menus {n}x", "modelType": "base",
                                          "modelId": "unsloth/Qwen3-4B", "createdAt": t0 + n, "updatedAt": t0 + n})
        msgs, parent = [], None
        for t in range(n):
            pair = turn(tid, t, parent, t0)
            msgs += pair
            parent = pair[1]["id"]
        _put(s, f"/api/chat/threads/{tid}/messages", {"messages": msgs, "pruneMissing": True})
        out[str(n)] = {"thread": tid, "messages": len(msgs),
                       "chars": sum(len(json.dumps(m["content"])) for m in msgs)}
    Path(a.out).write_text(json.dumps(out))
    print(json.dumps(out))
    return 0


# name, open action, open-ready predicate, close action, close-ready predicate
# action: ("key", chord) | ("click", css); predicate: ("overlay",) new visible dialog/menu/listbox,
# ("sel", css) visible, ("gone", css) not visible, ("settle",) DOM quiet only.
SURFACES = [
    ("settings", ("key", "Control+Comma"), ("overlay",), ("key", "Escape"), ("overlay_gone",)),
    ("browser_pane", ("click", 'button[aria-label="New tab"]'), ("sel", '[aria-label="Browser tabs"]'),
     ("click", 'button[aria-label="Close browser"]'), ("gone", '[aria-label="Browser tabs"]')),
    ("sidebar_toggle", ("key", "Control+b"), ("settle",), ("key", "Control+b"), ("settle",)),
    ("command_palette", ("key", "Control+p"), ("overlay",), ("key", "Escape"), ("overlay_gone",)),
    ("search_chats", ("key", "Control+k"), ("overlay",), ("key", "Escape"), ("overlay_gone",)),
    ("model_picker", ("key", "Control+Alt+m"), ("overlay",), ("key", "Escape"), ("overlay_gone",)),
    ("composer_menu", ("key", "Control+Shift+Period"), ("overlay",), ("key", "Escape"), ("overlay_gone",)),
    ("shortcuts_dialog", ("key", "Control+Slash"), ("overlay",), ("key", "Escape"), ("overlay_gone",)),
    ("chat_options", ("click", 'button[aria-label="Chat options"]'), ("overlay",), ("key", "Escape"),
     ("overlay_gone",)),
    ("tools_menu", ("click", 'button[aria-label="Tools and attachments"]'), ("overlay",), ("key", "Escape"),
     ("overlay_gone",)),
    ("run_settings", ("click", 'button[aria-label="Open run settings"]'), ("settle",),
     ("click", 'button[aria-label="Close run settings"]'), ("settle",)),
    ("api_monitor", ("key", "Control+Alt+Shift+m"), ("settle",), ("key", "Control+Alt+Shift+m"), ("settle",)),
    ("rename_chat", ("key", "Control+Alt+r"), ("settle",), ("key", "Escape"), ("settle",)),
]

PROBE_JS = r"""
() => {
  const OVER = '[role=dialog],[role=alertdialog],[role=menu],[role=listbox],[cmdk-root],[data-radix-popper-content-wrapper]';
  const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 1 && r.height > 1; };
  const overlays = () => [...document.querySelectorAll(OVER)].filter(vis).length;
  window.__overlays = overlays;
  window.__arm = (spec) => {
    const base = overlays();
    const st = {t0: null, ready: null, lastMut: null, muts: 0, added: [], gaps: [], done: false};
    const onIn = (e) => { if (st.t0 === null) st.t0 = e.timeStamp; };
    const evs = ['keydown', 'pointerdown', 'mousedown'];
    for (const ev of evs) document.addEventListener(ev, onIn, {capture: true});
    const mo = new MutationObserver((recs) => {
      st.lastMut = performance.now(); st.muts += recs.length;
      for (const r of recs) for (const n of r.addedNodes) {
        if (n.nodeType !== 1 || st.added.length >= 6) continue;
        st.added.push(`${n.tagName.toLowerCase()}[${n.getAttribute('role') || ''}|${n.getAttribute('aria-label') || ''}].${String(n.className || '').slice(0, 30)}`);
      }
    });
    mo.observe(document.documentElement, {subtree: true, childList: true, attributes: true, characterData: true});
    const k = spec[0];
    const pred = k === 'overlay' ? () => overlays() > base
      : k === 'overlay_gone' ? () => overlays() < base || overlays() === 0
      : k === 'sel' ? () => { const e = document.querySelector(spec[1]); return !!e && vis(e); }
      : k === 'gone' ? () => { const e = document.querySelector(spec[1]); return !e || !vis(e); }
      : null;
    let last = performance.now();
    const tick = (t) => {
      st.gaps.push([t, t - last]); last = t;
      if (st.t0 !== null && st.ready === null && pred && pred()) {
        st.ready = -1; requestAnimationFrame((t2) => { st.ready = t2; });
      }
      if (!st.done) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    window.__peek = () => ({t0: st.t0, ready: st.ready, quiet: st.lastMut === null ? null : performance.now() - st.lastMut,
                           hasPred: !!pred, now: performance.now()});
    window.__stop = () => {
      st.done = true; mo.disconnect();
      for (const ev of evs) document.removeEventListener(ev, onIn, {capture: true});
      const t0 = st.t0;
      const end = st.lastMut ?? (t0 ?? 0);
      const gaps = t0 === null ? [] : st.gaps.filter(([t]) => t >= t0 && t <= Math.max(end, st.ready || 0) + 50).map(([, g]) => g);
      return {
        triggered: t0 !== null,
        visible_ms: (t0 !== null && st.ready > 0) ? st.ready - t0 : null,
        settle_ms: (t0 !== null && st.lastMut !== null) ? st.lastMut - t0 : null,
        max_gap_ms: gaps.length ? Math.max(...gaps) : null,
        mutations: st.muts, added: st.added, overlays_after: overlays(),
      };
    };
    return base;
  };
  return true;
}
"""

SHAPE_JS = """() => ({
  nodes: document.getElementsByTagName('*').length,
  messages: document.querySelectorAll('[data-role][data-message-id]').length,
  overlays: window.__overlays ? window.__overlays() : null,
})"""


def med(xs):
    xs = [x for x in xs if x is not None]
    return round(statistics.median(xs), 1) if xs else None


async def act(page, action) -> bool:
    kind, arg = action
    if kind == "key":
        await page.keyboard.press(arg)
        return True
    loc = page.locator(arg)
    n = await loc.count()
    for i in range(n):
        el = loc.nth(i)
        if await el.is_visible():
            await el.click(timeout=5000)
            return True
    return False


async def step(page, action, pred, cap_s=8.0) -> dict:
    await page.evaluate("(s) => window.__arm(s)", list(pred))
    found = await act(page, action)
    if not found:
        r = await page.evaluate("() => window.__stop()")
        return {**r, "found": False}
    waited = 0.0
    while waited < cap_s:
        await page.wait_for_timeout(100)
        waited += 0.1
        pk = await page.evaluate("() => window.__peek()")
        ready_ok = (not pk["hasPred"]) or (pk["ready"] is not None and pk["ready"] > 0)
        if ready_ok and pk["quiet"] is not None and pk["quiet"] > 500:
            break
        if not pk["hasPred"] and pk["quiet"] is None and waited > 1.5:
            break
    r = await page.evaluate("() => window.__stop()")
    r["found"] = True
    r["timed_out"] = waited >= cap_s
    return r


TRACE_CATS = ["devtools.timeline", "toplevel", "disabled-by-default-devtools.timeline"]


def trace_summary(events: list) -> dict:
    mains = {(e["pid"], e["tid"]) for e in events
             if e.get("ph") == "M" and e.get("name") == "thread_name"
             and (e.get("args") or {}).get("name") == "CrRendererMain"}
    out = {"style_ms": 0.0, "elements_restyled": 0, "layout_ms": 0.0, "layout_objects": 0, "paint_ms": 0.0,
           "busy_ms": 0.0, "longest_task_ms": 0.0}
    stacks: dict = {}

    def add(name, dur_us, args_b, args_e):
        ms = dur_us / 1000
        if name == "UpdateLayoutTree":
            out["style_ms"] += ms
            out["elements_restyled"] += int((args_b or {}).get("elementCount") or (args_e or {}).get("elementCount") or 0)
        elif name == "Layout":
            out["layout_ms"] += ms
            bd = (args_b or {}).get("beginData") or {}
            out["layout_objects"] += int(bd.get("dirtyObjects") or 0)
        elif name in ("Paint", "PrePaint", "Layerize", "UpdateLayer", "PaintImage"):
            out["paint_ms"] += ms
        elif name in ("ThreadControllerImpl::RunTask", "RunTask"):
            out["busy_ms"] += ms
            out["longest_task_ms"] = max(out["longest_task_ms"], ms)

    for e in events:
        if (e.get("pid"), e.get("tid")) not in mains:
            continue
        ph, name = e.get("ph"), e.get("name")
        if ph == "X":
            add(name, e.get("dur", 0), e.get("args"), None)
        elif ph == "B":
            stacks.setdefault((e["tid"], name), []).append(e)
        elif ph == "E":
            st = stacks.get((e["tid"], name))
            if st:
                b = st.pop()
                add(name, e["ts"] - b["ts"], b.get("args"), e.get("args"))
    return {k: (round(v, 1) if isinstance(v, float) else v) for k, v in out.items()}


async def traced(page, cdp, action, pred) -> dict:
    events: list = []
    done = asyncio.Event()
    cdp.on("Tracing.dataCollected", lambda d: events.extend(d["value"]))
    cdp.on("Tracing.tracingComplete", lambda d: done.set())
    await cdp.send("Tracing.start", {"traceConfig": {"includedCategories": TRACE_CATS},
                                     "transferMode": "ReportEvents"})
    r = await step(page, action, pred)
    await cdp.send("Tracing.end")
    await asyncio.wait_for(done.wait(), 120)
    return {**trace_summary(events), "visible_ms": r.get("visible_ms"), "found": r.get("found")}


async def reset(page):
    for _ in range(2):
        await page.keyboard.press("Escape")
        await page.wait_for_timeout(150)
    await page.evaluate("() => { const a = document.activeElement; if (a && a !== document.body) a.blur(); }")
    await page.wait_for_timeout(400)


MAC_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)")


async def run_engine(p, engine, base, init, threads, arm, shots) -> dict:
    # webkit_mac: the same engine with the macOS desktop app's platform + UA, so WebKitGTK-only paths stay off
    browser = await getattr(p, engine.split("_")[0]).launch()
    res = {}
    try:
        for n, info in threads.items():
            extra = {"user_agent": MAC_UA} if engine == "webkit_mac" else {}
            ctx = await browser.new_context(viewport={"width": 1440, "height": 900}, **extra)
            if engine == "webkit_mac":
                await ctx.add_init_script("Object.defineProperty(Navigator.prototype, 'platform', {get: () => 'MacIntel'});")
            await ctx.add_init_script(init)
            page = await ctx.new_page()
            cdp = await ctx.new_cdp_session(page) if engine == "chromium" else None
            row = {"turns": int(n), "messages": info["messages"], "surfaces": {}}
            try:
                t0 = asyncio.get_event_loop().time()
                await page.goto(f"{base}/chat?thread={info['thread']}", wait_until="domcontentloaded")
                await page.wait_for_selector("form textarea", timeout=120_000)
                expected = info["messages"]
                last, stable = -1, None
                for _ in range(900):
                    m = await page.evaluate("() => document.querySelectorAll('[data-role][data-message-id]').length")
                    now = asyncio.get_event_loop().time()
                    if m >= expected:
                        break
                    if m != last:
                        last, stable = m, now
                    elif stable and now - stable > 8:
                        break
                    await page.wait_for_timeout(200)
                row["open_s"] = round(asyncio.get_event_loop().time() - t0, 1)
                await page.wait_for_timeout(3000)
                await page.evaluate(PROBE_JS)
                row["shape"] = await page.evaluate(SHAPE_JS)
                row["shape"]["webkitgtk_paths"] = await page.evaluate(
                    "() => /linux/i.test(navigator.platform + ' ' + navigator.userAgent) && /AppleWebKit/.test(navigator.userAgent) && !/android|chrom|edg/i.test(navigator.userAgent)")
                row["shape"]["windowed"] = await page.evaluate("() => document.querySelectorAll('[data-message-parked]').length")
                for name, op, opred, cl, cpred in SURFACES:
                    try:
                        row["surfaces"][name] = await asyncio.wait_for(
                            one_surface(page, cdp, engine, arm, n, name, op, opred, cl, cpred, shots), 180)
                    except asyncio.TimeoutError:
                        row["surfaces"][name] = {"status": "NOT_RUN: timed out after 180 s"}
                        await reset(page)
                    print("MENU", json.dumps({"arm": arm, "engine": engine, "turns": int(n), "surface": name,
                                              **{k: v for k, v in row["surfaces"][name].items() if k != "added"}}),
                          flush=True)
            except Exception as exc:  # noqa: BLE001
                row["error"] = repr(exc)[:400]
                print("MENU_ERROR", arm, engine, n, row["error"], flush=True)
            finally:
                await ctx.close()
            res[n] = row
    finally:
        await browser.close()
    return res


async def one_surface(page, cdp, engine, arm, n, name, op, opred, cl, cpred, shots) -> dict:
    s = {"open": [], "close": []}
    await reset(page)
    for c in range(CYCLES):
        o = await step(page, op, opred)
        s["open"].append(o)
        if c == 0 and shots and o.get("found"):
            await page.screenshot(path=str(Path(shots) / f"{arm}_{engine}_{n}x_{name}.jpg"),
                                  type="jpeg", quality=45)
        if not o.get("found"):
            break
        await page.wait_for_timeout(300)
        s["close"].append(await step(page, cl, cpred))
        await reset(page)
    if cdp is not None and s["open"] and s["open"][0].get("found"):
        try:
            s["trace_open"] = await traced(page, cdp, op, opred)
            await page.wait_for_timeout(300)
            s["trace_close"] = await traced(page, cdp, cl, cpred)
        except Exception as exc:  # noqa: BLE001
            s["trace_error"] = repr(exc)[:200]
        await reset(page)
    first = s["open"][0] if s["open"] else {}
    status = ("NOT_RUN: trigger not found" if not first.get("found")
              else "NOT_RUN: no input event" if not first.get("triggered")
              else "NOT_RUN: surface never appeared" if opred[0] != "settle" and first.get("visible_ms") is None
              else "OK")
    return {
        "status": status,
        "open_visible_ms": med(o.get("visible_ms") for o in s["open"]),
        "open_settle_ms": med(o.get("settle_ms") for o in s["open"]),
        "open_max_gap_ms": med(o.get("max_gap_ms") for o in s["open"]),
        "close_visible_ms": med(c.get("visible_ms") for c in s["close"]),
        "close_settle_ms": med(c.get("settle_ms") for c in s["close"]),
        "close_max_gap_ms": med(c.get("max_gap_ms") for c in s["close"]),
        "open_all": [o.get("visible_ms") or o.get("settle_ms") for o in s["open"]],
        "added": first.get("added"),
        "trace_open": s.get("trace_open"), "trace_close": s.get("trace_close"),
        "trace_error": s.get("trace_error"),
    }


async def run_async(a) -> int:
    from playwright.async_api import async_playwright

    s = studio_session(a.base_url, Path(a.home), PASSWORD)
    auth = type("A", (), {"access_token": s.access_token, "refresh_token": s.refresh_token})()
    init = seed_init_script(auth, [])
    threads = json.loads(Path(a.threads).read_text())
    if a.shots:
        Path(a.shots).mkdir(parents=True, exist_ok=True)
    out = {"arm": a.arm, "engines": {}}
    async with async_playwright() as p:
        for engine in a.engines.split(","):
            out["engines"][engine] = await run_engine(p, engine, a.base_url, init, threads, a.arm, a.shots)
    Path(a.out).write_text(json.dumps(out))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s1 = sub.add_parser("seed")
    s1.add_argument("--base-url", required=True)
    s1.add_argument("--home", required=True)
    s1.add_argument("--turns", type=int, nargs="+", default=[1, 100])
    s1.add_argument("--out", required=True)
    s2 = sub.add_parser("run")
    s2.add_argument("--base-url", required=True)
    s2.add_argument("--home", required=True)
    s2.add_argument("--threads", required=True)
    s2.add_argument("--arm", required=True)
    s2.add_argument("--engines", default="chromium,webkit,webkit_mac")
    s2.add_argument("--shots")
    s2.add_argument("--out", required=True)
    a = ap.parse_args()
    return cmd_seed(a) if a.cmd == "seed" else asyncio.run(run_async(a))


if __name__ == "__main__":
    raise SystemExit(main())
